﻿import { useMemo, useState } from 'react'
import {
  GraduationCap, LayoutDashboard, BookOpen, CalendarDays,
  BrainCircuit, Bookmark, Search, Bell, ChevronDown,
  ArrowUpRight, Clock3, Sparkles, Play, MoreHorizontal,
  Flame, Target, CheckCircle2, Menu, X,
  MessageCircle, TrendingUp, Send, Headphones, Layers
} from 'lucide-react'
import './App.css'

const courses = [
  { id: 1, name: 'Business Statistics', code: 'BBA 204', progress: 78, color: 'purple', lessons: '12 of 16 lessons', icon: '📊' },
  { id: 2, name: 'Principles of Management', code: 'BBA 201', progress: 62, color: 'blue', lessons: '8 of 13 lessons', icon: '📚' },
  { id: 3, name: 'Research Methods', code: 'BBA 305', progress: 45, color: 'orange', lessons: '5 of 11 lessons', icon: '🔬' },
]

const navigation = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'My courses', icon: BookOpen },
  { label: 'Study planner', icon: CalendarDays },
  { label: 'AI tutor', icon: BrainCircuit },
  { label: 'Saved materials', icon: Bookmark },
]

function App() {
  const [activePage, setActivePage] = useState('Overview')
  const [search, setSearch] = useState('')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [question, setQuestion] = useState('')
  const [messages, setMessages] = useState<string[]>([])

  const filteredCourses = useMemo(
    () => courses.filter(course =>
      `${course.name} ${course.code}`.toLowerCase().includes(search.toLowerCase())
    ),
    [search]
  )

  function askTutor(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!question.trim()) return
    setMessages(previous => [...previous, question.trim()])
    setQuestion('')
  }

  function navigate(page: string) {
    setActivePage(page)
    setMobileMenu(false)
  }

  return (
    <div className="app-shell">
      {mobileMenu && <button className="mobile-overlay" aria-label="Close menu" onClick={() => setMobileMenu(false)} />}

      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-icon"><GraduationCap size={25} /></div>
          <div>
            <strong>Learnova</strong>
            <span>LEARN · GROW · EXCEL</span>
          </div>
          <button className="close-menu" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X /></button>
        </div>

        <div className="nav-label">MENU</div>
        <nav className="main-nav">
          {navigation.map(item => {
            const Icon = item.icon
            return (
              <button key={item.label} className={`nav-item ${activePage === item.label ? 'active' : ''}`} onClick={() => navigate(item.label)}>
                <Icon size={19} />
                <span>{item.label}</span>
                {item.label === 'AI tutor' && <span className="new-tag">NEW</span>}
              </button>
            )
          })}
        </nav>

        <div className="nav-label tools-label">YOUR TOOLS</div>
        <button className="nav-item" onClick={() => navigate('Study planner')}><Layers size={19} /><span>Flashcards</span></button>
        <button className="nav-item" onClick={() => navigate('Study planner')}><Target size={19} /><span>Practice tests</span></button>

        <div className="sidebar-bottom">
          <div className="upgrade-card">
            <div className="upgrade-icon"><Sparkles size={19} /></div>
            <strong>Unlock your potential</strong>
            <p>Get more from your learning journey.</p>
            <button onClick={() => navigate('Subscription')}>Explore plans <ArrowUpRight size={15} /></button>
          </div>
          <button className="profile-mini" onClick={() => navigate('Settings')}>
            <div className="avatar">JD</div>
            <div className="profile-info"><strong>Jean Dedieu</strong><span>Student account</span></div>
            <MoreHorizontal size={19} />
          </button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu /></button>
            <div className="breadcrumb">Workspace <span>/</span> <strong>{activePage}</strong></div>
          </div>
          <div className="topbar-actions">
            <label className="search-box">
              <Search size={18} />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search courses, materials..." />
              <kbd>⌘ K</kbd>
            </label>
            <button className="icon-button notification-button" aria-label="Notifications"><Bell size={19} /><i /></button>
            <button className="top-profile"><div className="avatar">JD</div><ChevronDown size={15} /></button>
          </div>
        </header>

        <div className="page-content">
          <section className="welcome-row">
            <div>
              <div className="eyebrow"><Sparkles size={15} /> YOUR LEARNING SPACE</div>
              <h1>{activePage === 'Overview' ? 'Good morning, Jean' : activePage}<span className="wave">✦</span></h1>
              <p className="welcome-subtitle">Every small step brings you closer to your goals. Let's make today count.</p>
            </div>
            <button className="date-chip"><CalendarDays size={16} /> Wednesday, November 19 <ChevronDown size={14} /></button>
          </section>

          <section className="hero-banner">
            <div className="hero-copy">
              <span className="hero-kicker"><Sparkles size={14} /> YOUR PERSONAL LEARNING COMPANION</span>
              <h2>Make today a<br /><span>great learning day.</span></h2>
              <p>Your next breakthrough is one lesson away. Keep going!</p>
              <button className="hero-button" onClick={() => navigate('My courses')}>Continue learning <ArrowUpRight size={17} /></button>
            </div>
            <div className="hero-art">
              <div className="art-circle circle-one" />
              <div className="art-circle circle-two" />
              <div className="art-book">📖</div>
              <div className="art-star star-one">✦</div>
              <div className="art-star star-two">✧</div>
              <div className="floating-note"><Flame size={17} /> 7 day streak</div>
              <div className="floating-progress"><TrendingUp size={17} /> You're improving!</div>
            </div>
          </section>

          <section className="stats-grid">
            <article className="stat-card">
              <div className="stat-top"><span className="stat-icon purple-icon"><BookOpen size={19} /></span><span className="stat-change">+2 this week</span></div>
              <strong>12</strong><span className="stat-caption">Courses enrolled</span>
            </article>
            <article className="stat-card">
              <div className="stat-top"><span className="stat-icon blue-icon"><Clock3 size={19} /></span><span className="stat-change">+3.5 hrs</span></div>
              <strong>24.5 <small>hrs</small></strong><span className="stat-caption">Learning time</span>
            </article>
            <article className="stat-card">
              <div className="stat-top"><span className="stat-icon orange-icon"><Target size={19} /></span><span className="stat-change">Great progress</span></div>
              <strong>86<small>%</small></strong><span className="stat-caption">Average performance</span>
            </article>
            <article className="stat-card">
              <div className="stat-top"><span className="stat-icon green-icon"><Flame size={19} /></span><span className="stat-change">Personal best!</span></div>
              <strong>7 <small>days</small></strong><span className="stat-caption">Learning streak</span>
            </article>
          </section>

          <div className="content-grid">
            <section className="courses-section">
              <div className="section-heading">
                <div><h3>Continue learning</h3><p>Pick up where you left off</p></div>
                <button className="text-link" onClick={() => navigate('My courses')}>View all courses <ArrowUpRight size={15} /></button>
              </div>
              <div className="course-list">
                {filteredCourses.map(course => (
                  <article className="course-card" key={course.id}>
                    <div className={`course-symbol ${course.color}`}>{course.icon}</div>
                    <div className="course-details">
                      <span className="course-code">{course.code}</span>
                      <h4>{course.name}</h4>
                      <div className="progress-meta"><span>{course.lessons}</span><strong>{course.progress}%</strong></div>
                      <div className="progress-track"><div className={`progress-fill ${course.color}`} style={{ width: `${course.progress}%` }} /></div>
                    </div>
                    <button className="course-play" aria-label={`Continue ${course.name}`} onClick={() => navigate('My courses')}><Play size={17} fill="currentColor" /></button>
                  </article>
                ))}
                {filteredCourses.length === 0 && <div className="empty-state">No matching courses found. Try another search.</div>}
              </div>
            </section>

            <section className="tutor-section">
              <div className="section-heading"><div><h3>Your AI study buddy</h3><p>Here whenever you need help</p></div><span className="online-dot" /></div>
              <div className="tutor-card">
                <div className="tutor-top"><div className="tutor-avatar"><BrainCircuit size={25} /></div><div><strong>Meet your AI tutor</strong><span><i /> Ready to help you learn</span></div></div>
                <p className="tutor-description">Need something explained? Have a question? Let's figure it out together.</p>
                <div className="suggestion-chips">
                  <button onClick={() => setQuestion('Explain a difficult topic to me')}>Explain a topic</button>
                  <button onClick={() => setQuestion('Help me prepare for exams')}>Exam preparation</button>
                  <button onClick={() => setQuestion('Create practice questions for me')}>Practice questions</button>
                </div>
                {messages.map((message, index) => <div className="demo-message" key={index}><MessageCircle size={14} /> {message}</div>)}
                <form className="tutor-input" onSubmit={askTutor}>
                  <input value={question} onChange={e => setQuestion(e.target.value)} placeholder="Ask me anything..." aria-label="Ask your AI tutor" />
                  <button type="submit" aria-label="Send question"><Send size={17} /></button>
                </form>
                <span className="tutor-footnote"><Sparkles size={12} /> AI tutor connection will be enabled in a later stage</span>
              </div>
            </section>
          </div>

          <div className="bottom-grid">
            <section className="activity-section">
              <div className="section-heading"><div><h3>Upcoming activities</h3><p>Stay ahead of your deadlines</p></div><button className="text-link" onClick={() => navigate('Study planner')}>See calendar <ArrowUpRight size={15} /></button></div>
              <div className="activity-row"><div className="activity-date"><strong>22</strong><span>NOV</span></div><div className="activity-info"><strong>Business Statistics CAT</strong><span><Clock3 size={13} /> Saturday · 09:00 AM</span></div><span className="activity-type assessment">Assessment</span></div>
              <div className="activity-row"><div className="activity-date blue-date"><strong>25</strong><span>NOV</span></div><div className="activity-info"><strong>Research proposal submission</strong><span><Clock3 size={13} /> Tuesday · 11:59 PM</span></div><span className="activity-type assignment">Assignment</span></div>
            </section>
            <section className="goal-section">
              <div className="section-heading"><div><h3>Weekly goal</h3><p>You're doing amazing!</p></div><Target size={20} className="goal-heading-icon" /></div>
              <div className="goal-number"><strong>8.5</strong><span>/ 12 hours</span></div>
              <div className="goal-track"><div /></div>
              <div className="goal-footer"><span><CheckCircle2 size={14} /> 71% completed</span><span>3.5 hrs to go</span></div>
            </section>
          </div>

          <footer className="footer"><span>© 2026 Learnova. Built for your learning journey.</span><span><Headphones size={14} /> Need help? We're here for you.</span></footer>
        </div>
      </main>
    </div>
  )
}

export default App

